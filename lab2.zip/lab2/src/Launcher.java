/* File: Launcher.java
 * Author: Stanley Pieda
 * Date: 2015
 * Description: Demonstration of DAO Design Pattern, MVC Design Pattern
 */
public class Launcher {
	public static void main(String[] args) {
		 (new SimpleDemo()).demo();
	}
}