/* File: AuthorsDataAccessObjectImplementation.java
 * Author: Stanley Pieda
 * Date: 2015
 * Modified: May/2022 removal explicit boxing of int with Integer() - kriger
 * Description: Demonstration of DAO Design Pattern, MVC Design Pattern
 * References:
 * Ram N. (2013).  Data Access Object Design Pattern or DAO Pattern [blog] Retrieved from
 * http://ramj2ee.blogspot.in/2013/08/data-access-object-design-pattern-or.html
 */
package dataaccesslayer;

import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

import transferobjects.RecipientDTO;

import java.util.ArrayList;
import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.ResultSetMetaData;
import java.sql.Statement;

public  class RecipientsDaoImpl implements RecipientsDao{
    


  

        @Override
	public List<RecipientDTO> getAllRecipients() {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
                
                
                
                ArrayList<RecipientDTO> recipients = null;

    		try{
      
                        DataSource ds = new DataSource();
			con = ds.createConnection();
			pstmt = con.prepareStatement(
					"SELECT AwardID, Name, Year, City,Category FROM Recipients ORDER BY AwardID");
			rs = pstmt.executeQuery();                      
                      	recipients = new ArrayList<>();
			while(rs.next()){
				RecipientDTO recipient = new RecipientDTO();
				recipient.setAwardID(rs.getInt("AwardID"));
				recipient.setName(rs.getString("Name"));
				recipient.setYear(rs.getInt("Year"));
                                recipient.setCity(rs.getString("City"));
                                recipient.setCategory(rs.getString("Category"));
				recipients.add(recipient);
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
                      
                   
			try{ if(rs != null){ rs.close(); } }
			catch(SQLException ex){System.out.println(ex.getMessage());}
                        
			try{ if(pstmt != null){ pstmt.close(); }}
			catch(SQLException ex){System.out.println(ex.getMessage());}
                        
			try{ if(con != null){ con.close(); }}
			catch(SQLException ex){System.out.println(ex.getMessage());}
		}
		return recipients;
	}

	@Override
	public RecipientDTO getRecipientByAwardID(Integer AwardID) {
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		RecipientDTO recipient = null;
      
                try{
			DataSource ds = new DataSource();
			con = ds.createConnection();
			pstmt = con.prepareStatement(
					"SELECT AwardID, Name, City, Category FROM Recipient WHERE AwardID = ?");
			pstmt.setInt(1, AwardID);
			rs = pstmt.executeQuery();
  
			while(rs.next()){
                                recipient = new RecipientDTO();
				recipient.setAwardID(rs.getInt("AwardID"));
				recipient.setName(rs.getString("Name"));
				recipient.setYear(rs.getInt("Year"));
                                recipient.setCity(rs.getString("City"));
                                recipient.setCategory(rs.getString("Category"));
				
			}
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
                      
			try{ if(rs != null){ rs.close(); } }
			catch(SQLException ex){System.out.println(ex.getMessage());}
			try{ if(pstmt != null){ pstmt.close(); }}
			catch(SQLException ex){System.out.println(ex.getMessage());}
			try{ if(con != null){ con.close(); }}
			catch(SQLException ex){System.out.println(ex.getMessage());}
		}
		return recipient;
	}

	@Override
	public void addRecipient(RecipientDTO recipient) {
		Connection con = null;
		PreparedStatement pstmt = null;
                Statement statement;
                ResultSet rs ;
                 ResultSetMetaData rsmd  ;
                 
             
                  try{

                      //metadata!!!!
                      DataSource ds = new DataSource();
			con = ds.createConnection();
                    pstmt = con.prepareStatement(
					"SELECT AwardID, Name, Year, City,Category FROM Recipients ORDER BY AwardID");
                    rs = pstmt.executeQuery(); 
                    rsmd = rs.getMetaData();
                    int columnCount = rsmd.getColumnCount();
                    
                    
                    System.out.println( "Recipients Table of Database:\n" );
                    for ( int i = 1; i <= columnCount; i++ )
                        //resultset!!!!!!
                        System.out.printf( "%-20s\t", rsmd.getColumnName( i ) );
                    
                    System.out.println();
                    while ( rs.next() )          
                    {
            for ( int i = 1; i <= columnCount; i++ )
               System.out.printf( "%-8s\t", rs.getObject( i ) );
//            System.out.println();
            System.out.printf("\n");
         }
                    
                    System.out.println( "\nAuthors Table - Column Attributes:" );
                    for(int i =1; i <= columnCount; i++){
                        System.out.printf( "%-8s\t", rsmd.getColumnName( i ) );
                        System.out.printf( "%-8s\t", rsmd.getColumnTypeName(i) );
                        System.out.printf( "%-8s\t", rsmd.getColumnClassName(i) );
                        System.out.printf("\n");
                         
                    }
                     System.out.printf("\n");
                      System.out.printf("\n");
                       System.out.printf("\n");
                }catch (SQLException e){
                    e.printStackTrace();
                }
                  
		try{
			DataSource ds = new DataSource();
			con = ds.createConnection();
			// do not insert AuthorID, it is generated by Database
			pstmt = con.prepareStatement(
					"INSERT INTO Recipients (Name, Year, City, Category) " +
			        "VALUES(?, ?,?,?)");
			pstmt.setString(1, recipient.getName());
			pstmt.setInt(2, recipient.getYear());
                        pstmt.setString(3, recipient.getCity());
                        pstmt.setString(4, recipient.getCategory());
			pstmt.executeUpdate();
		}
		catch(SQLException e){
//			e.printStackTrace();
		}
		finally{
			try{ if(pstmt != null){ pstmt.close(); }}
			catch(SQLException ex){System.out.println(ex.getMessage());}
			try{ if(con != null){ con.close(); }}
			catch(SQLException ex){System.out.println(ex.getMessage());}
		}
	}

	@Override
	public void updateRecipient(RecipientDTO recipient) {
			Connection con = null;
			PreparedStatement pstmt = null;
			try{
				DataSource ds = new DataSource();
				con = ds.createConnection();
				pstmt = con.prepareStatement(
						"UPDATE Recipients SET Name = ?, " + " City =?, Year = ?,"+
				        "Category  = ? WHERE awardID = ?");
				pstmt.setString(1, recipient.getName());
				pstmt.setString(2, recipient.getCity());
                                pstmt.setInt(3, recipient.getYear());
                                pstmt.setString(4, recipient.getCategory());
                                pstmt.setInt(5, recipient.getAwardID().intValue());
				pstmt.executeUpdate();
			}
			catch(SQLException e){
				e.printStackTrace();
			}
			finally{
				try{ if(pstmt != null){ pstmt.close(); }}
				catch(SQLException ex){System.out.println(ex.getMessage());}
				try{ if(con != null){ con.close(); }}
				catch(SQLException ex){System.out.println(ex.getMessage());}
			}
	}

        @Override
	public void deleteRecipient(RecipientDTO recipient) {
		Connection con = null;
		PreparedStatement pstmt = null;
                ResultSet rs = null;
		try{
			DataSource ds = new DataSource();
			con = ds.createConnection();
			pstmt = con.prepareStatement(
					"DELETE FROM recipients WHERE AwardID = ?");	
			pstmt.setInt(1, recipient.getAwardID().intValue());
			pstmt.executeUpdate();
		}
		catch(SQLException e){
			e.printStackTrace();
		}
		finally{
			try{ if(pstmt != null){ pstmt.close(); }}
			catch(SQLException ex){System.out.println(ex.getMessage());}
			try{ if(con != null){ con.close(); }}
			catch(SQLException ex){System.out.println(ex.getMessage());}
		}
                
                  // connect to database books and query database
    
     
	}
        
          // connect to database books and query database
     

    @Override
    public void addAttribute(RecipientDTO recipient) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
