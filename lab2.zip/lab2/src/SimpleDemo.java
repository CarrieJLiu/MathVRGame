/* File: SimpleDemo.java
 * Author: Stanley Pieda
 * Date: 2015
 * Description: Demonstration of DAO Design Pattern, MVC Design Pattern
 */
import businesslayer.RecipientsBusinessLogic;
import transferobjects.RecipientDTO;
import businesslayer.ValidationException;

import java.util.List;
public class SimpleDemo {

	public void demo() {
           
            try{
                RecipientsBusinessLogic logic = new RecipientsBusinessLogic();
            List<RecipientDTO> list = null;
            RecipientDTO recipient = null;
            
            System.out.println("Printing Recipients");
            list = logic.getAllRecipients();
            printRecipients(list);
            
//            System.out.println("Printing One Recipient");
//            recipient = logic.getRecipient(1);
//            printRecipient(recipient);
//            System.out.println();


            
                        System.out.println("Inserting One Recipient");
			recipient = new RecipientDTO();
			recipient.setName("LIU Jiali");
			recipient.setCity("Ottawa");
                        recipient.setYear(1997);
                        recipient.setCategory("Programming");
			logic.addRecipient(recipient);
			list = logic.getAllRecipients();
			printRecipients(list);
			
			System.out.println("Updating last recipient");
			Integer updatePrimaryKey = list.get(list.size() - 1).getAwardID();
			recipient = new RecipientDTO();
			recipient.setAwardID(updatePrimaryKey);
			recipient.setName("Carrie Lau");
			recipient.setCity("Ottawa");
                          recipient.setYear(1984);
                        recipient.setCategory("tester");
			logic.updateRecipient(recipient);
			list = logic.getAllRecipients();
			printRecipients(list);
            

                        System.out.println("Deleting last Recipient");
                        recipient = list.get(list.size() - 1);
                        logic.deleteRecipient(recipient);
                        list = logic.getAllRecipients();
                        printRecipients(list);
            }
            
            		catch(ValidationException e){
			System.err.println(e.getMessage());
		}


	}	private static void printRecipient(RecipientDTO recipient){
            String output = String.format("%s, %s, %s, %s, %s",
	    			recipient.getAwardID().toString(),
	    			recipient.getName(),
	    			recipient.getYear().toString(),
                                recipient.getCity(),
                                recipient.getCategory());
	    	System.out.println(output);
	}
	
	private static void printRecipients(List<RecipientDTO> recipients){
	    for(RecipientDTO recipient : recipients){
	    	printRecipient(recipient);
	    }
	    System.out.println();
	}



}
